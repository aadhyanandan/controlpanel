import React from 'react';

  function Figma() {
    return (
      <div>
        <h1>Figma</h1>
        <p>Welcome to the Figma application!</p>
      </div>
    );
  }

  export default Figma;
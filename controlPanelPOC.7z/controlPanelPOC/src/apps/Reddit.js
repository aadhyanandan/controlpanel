import React from 'react';

  function Reddit() {
    return (
      <div>
        <h1>Reddit</h1>
        <p>Welcome to the Reddit application!</p>
      </div>
    );
  }

  export default Reddit;
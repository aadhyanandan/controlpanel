import React from 'react';

  function Spotify() {
    return (
      <div>
        <h1>Spotify</h1>
        <p>Welcome to the Spotify application!</p>
      </div>
    );
  }

  export default Spotify;
import React from 'react';

  function Trello() {
    return (
      <div>
        <h1>Trello</h1>
        <p>Welcome to the Trello application!</p>
      </div>
    );
  }

  export default Trello;
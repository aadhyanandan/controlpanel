import React from 'react';

  function YouTube() {
    return (
      <div>
        <h1>YouTube</h1>
        <p>Welcome to the YouTube application!</p>
      </div>
    );
  }

  export default YouTube;
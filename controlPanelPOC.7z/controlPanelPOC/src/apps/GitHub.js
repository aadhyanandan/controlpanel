import React from 'react';

  function GitHub() {
    return (
      <div>
        <h1>GitHub</h1>
        <p>Welcome to the GitHub application!</p>
      </div>
    );
  }

  export default GitHub;
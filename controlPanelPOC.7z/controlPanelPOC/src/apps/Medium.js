import React from 'react';

  function Medium() {
    return (
      <div>
        <h1>Medium</h1>
        <p>Welcome to the Medium application!</p>
      </div>
    );
  }

  export default Medium;
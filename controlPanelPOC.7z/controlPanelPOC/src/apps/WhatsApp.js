import React from 'react';

  function WhatsApp() {
    return (
      <div>
        <h1>WhatsApp</h1>
        <p>Welcome to the WhatsApp application!</p>
      </div>
    );
  }

  export default WhatsApp;
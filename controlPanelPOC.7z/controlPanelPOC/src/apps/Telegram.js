import React from 'react';

  function Telegram() {
    return (
      <div>
        <h1>Telegram</h1>
        <p>Welcome to the Telegram application!</p>
      </div>
    );
  }

  export default Telegram;
import React from 'react';

  function Instagram() {
    return (
      <div>
        <h1>Instagram</h1>
        <p>Welcome to the Instagram application!</p>
      </div>
    );
  }

  export default Instagram;
import React from 'react';

  function Dropbox() {
    return (
      <div>
        <h1>Dropbox</h1>
        <p>Welcome to the Dropbox application!</p>
      </div>
    );
  }

  export default Dropbox;
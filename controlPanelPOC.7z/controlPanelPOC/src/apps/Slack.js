import React from 'react';

  function Slack() {
    return (
      <div>
        <h1>Slack</h1>
        <p>Welcome to the Slack application!</p>
      </div>
    );
  }

  export default Slack;
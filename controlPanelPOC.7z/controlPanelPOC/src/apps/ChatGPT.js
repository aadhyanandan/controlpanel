import React from 'react';

  function ChatGPT() {
    return (
      <div>
        <h1>ChatGPT</h1>
        <p>Welcome to the ChatGPT application!</p>
      </div>
    );
  }

  export default ChatGPT;
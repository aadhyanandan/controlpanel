import React from 'react';

  function LinkedIn() {
    return (
      <div>
        <h1>LinkedIn</h1>
        <p>Welcome to the LinkedIn application!</p>
      </div>
    );
  }

  export default LinkedIn;
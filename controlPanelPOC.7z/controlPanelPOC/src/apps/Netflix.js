import React from 'react';

  function Netflix() {
    return (
      <div>
        <h1>Netflix</h1>
        <p>Welcome to the Netflix application!</p>
      </div>
    );
  }

  export default Netflix;
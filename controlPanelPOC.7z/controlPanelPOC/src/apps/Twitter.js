import React from 'react';

  function Twitter() {
    return (
      <div>
        <h1>Twitter</h1>
        <p>Welcome to the Twitter application!</p>
      </div>
    );
  }

  export default Twitter;
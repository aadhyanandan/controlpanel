import React from 'react';

  function Discord() {
    return (
      <div>
        <h1>Discord</h1>
        <p>Welcome to the Discord application!</p>
      </div>
    );
  }

  export default Discord;
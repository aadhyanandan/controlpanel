import React from 'react';

  function Zoom() {
    return (
      <div>
        <h1>Zoom</h1>
        <p>Welcome to the Zoom application!</p>
      </div>
    );
  }

  export default Zoom;
import React from 'react';

  function Pinterest() {
    return (
      <div>
        <h1>Pinterest</h1>
        <p>Welcome to the Pinterest application!</p>
      </div>
    );
  }

  export default Pinterest;
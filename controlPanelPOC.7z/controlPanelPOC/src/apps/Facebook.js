import React from 'react';

  function Facebook() {
    return (
      <div>
        <h1>Facebook</h1>
        <p>Welcome to the Facebook application!</p>
      </div>
    );
  }

  export default Facebook;
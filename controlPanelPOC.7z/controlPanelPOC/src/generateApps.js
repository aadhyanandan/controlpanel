const fs = require("fs");
const path = require("path");

const apps = [
  "Instagram",
  "Facebook",
  "GitHub",
  "ChatGPT",
  "Twitter",
  "LinkedIn",
  "Slack",
  "Spotify",
  "Netflix",
  "Zoom",
  "YouTube",
  "Pinterest",
  "Dropbox",
  "Reddit",
  "Trello",
  "Figma",
  "WhatsApp",
  "Telegram",
  "Medium",
  "Discord",
];

const appsDir = path.join(__dirname, "apps");

if (!fs.existsSync(appsDir)) {
  fs.mkdirSync(appsDir, { recursive: true });
}

apps.forEach((appName) => {
  const componentContent = `
  import React from 'react';

  function ${appName}() {
    return (
      <div>
        <h1>${appName}</h1>
        <p>Welcome to the ${appName} application!</p>
      </div>
    );
  }

  export default ${appName};
  `;
  const filePath = path.join(appsDir, `${appName}.js`);
  fs.writeFileSync(filePath, componentContent.trim());
});

console.log("App components generated successfully!");

import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./components/Home";
import Header from "./components/header";

// Importing individual apps
import ChatGPT from "./apps/ChatGPT";
import Dropbox from "./apps/Dropbox";
import Instagram from "./apps/Instagram";
import Facebook from "./apps/Facebook";
import GitHub from "./apps/GitHub";
import Twitter from "./apps/Twitter";
import LinkedIn from "./apps/LinkedIn";
import Slack from "./apps/Slack";
import Spotify from "./apps/Spotify";
import Netflix from "./apps/Netflix";
import Zoom from "./apps/Zoom";
import YouTube from "./apps/YouTube";
import Pinterest from "./apps/Pinterest";
import Reddit from "./apps/Reddit";
import Trello from "./apps/Trello";
import Figma from "./apps/Figma";
import WhatsApp from "./apps/WhatsApp";
import Telegram from "./apps/Telegram";
import Medium from "./apps/Medium";
import Discord from "./apps/Discord";

function App() {
  return (
    <Router>
      <Header />
      <Routes>
        {/* Home route */}
        <Route path="/" element={<Home />} />

        {/* Routes for each app */}
        <Route path="/chatgpt" element={<ChatGPT />} />
        <Route path="/dropbox" element={<Dropbox />} />
        <Route path="/instagram" element={<Instagram />} />
        <Route path="/facebook" element={<Facebook />} />
        <Route path="/github" element={<GitHub />} />
        <Route path="/twitter" element={<Twitter />} />
        <Route path="/linkedin" element={<LinkedIn />} />
        <Route path="/slack" element={<Slack />} />
        <Route path="/spotify" element={<Spotify />} />
        <Route path="/netflix" element={<Netflix />} />
        <Route path="/zoom" element={<Zoom />} />
        <Route path="/youtube" element={<YouTube />} />
        <Route path="/pinterest" element={<Pinterest />} />
        <Route path="/reddit" element={<Reddit />} />
        <Route path="/trello" element={<Trello />} />
        <Route path="/figma" element={<Figma />} />
        <Route path="/whatsapp" element={<WhatsApp />} />
        <Route path="/telegram" element={<Telegram />} />
        <Route path="/medium" element={<Medium />} />
        <Route path="/discord" element={<Discord />} />
      </Routes>
    </Router>
  );
}

export default App;

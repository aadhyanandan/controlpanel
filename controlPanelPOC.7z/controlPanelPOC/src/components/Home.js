import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Grid, Card, CardContent, Typography, Box, TextField } from "@mui/material";

// Dummy app data
const apps = [
  { name: "Instagram", description: "A photo and video sharing app" },
  { name: "Facebook", description: "A social networking platform" },
  { name: "GitHub", description: "A platform for developers" },
  { name: "ChatGPT", description: "An AI-powered chatbot" },
  { name: "Twitter", description: "A microblogging platform" },
  { name: "LinkedIn", description: "A professional networking site" },
  { name: "Slack", description: "A communication tool for teams" },
  { name: "Spotify", description: "A music streaming service" },
  { name: "Netflix", description: "A video streaming platform" },
  { name: "Zoom", description: "A video conferencing tool" },
  { name: "YouTube", description: "A video sharing platform" },
  { name: "Pinterest", description: "An image sharing app" },
  { name: "Dropbox", description: "A cloud storage service" },
  { name: "Reddit", description: "A discussion and community platform" },
  { name: "Trello", description: "A project management tool" },
  { name: "Figma", description: "A design collaboration platform" },
  { name: "WhatsApp", description: "A messaging app" },
  { name: "Telegram", description: "A secure messaging app" },
  { name: "Medium", description: "A blogging platform" },
  { name: "Discord", description: "A community-building app" },
];

function Home() {
  const [searchQuery, setSearchQuery] = useState(""); // State for search query
  const navigate = useNavigate();

  // Filtered apps based on search query
  const filteredApps = apps.filter((app) =>
    app.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Handles navigation on card click
  const handleNavigation = (appName) => {
    navigate(`/${appName.toLowerCase()}`);
  };

  return (
    <Box sx={{ p: 3 }}>
      {/* Search Bar */}
      <Box sx={{ mb: 4, display: "flex", justifyContent: "center" }}>
        <TextField
        size="small"
          variant="outlined"
          label="Search Applications"
          onChange={(e) => setSearchQuery(e.target.value)}
          sx={{ width: "100%", maxWidth: 400 }}
        />
      </Box>

      {/* Cards */}
      <Grid container spacing={3}>
        {filteredApps.length > 0 ? (
          filteredApps.map((app) => (
            <Grid item xs={12} sm={6} md={4} lg={3} key={app.name}>
              <Card
                sx={{ cursor: "pointer", ":hover": { boxShadow: 6 } }}
                onClick={() => handleNavigation(app.name)}
              >
                <CardContent>
                  <Typography variant="h6" gutterBottom>
                    {app.name}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {app.description}
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
          ))
        ) : (
          <Typography
            variant="body1"
            sx={{ textAlign: "center", width: "100%", mt: 4 }}
          >
            No applications found.
          </Typography>
        )}
      </Grid>
    </Box>
  );
}

export default Home;

import React from "react";
import AppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";
import Avatar from "@mui/material/Avatar";
import IconButton from "@mui/material/IconButton";
import { useNavigate } from "react-router-dom";

function Header() {
    const navigate = useNavigate()

    const navigateToHome = () => {
        navigate('/')
    }
  return (
    <AppBar position="static" color="primary">
      <Toolbar sx={{display:"felx", justifyContent:"space-between", alignItems:"center"}}>
        {/* Left Side: Control Panel Text */}
        <Typography onClick={navigateToHome} variant="h6" component="div" sx={{ flexGrow: 0, cursor:"pointer" }}>
          Control Panel
        </Typography>

        {/* Right Side: User Icon and Name */}
        <Box display="flex" alignItems="center">
          <IconButton size="large" color="inherit">
            <Avatar alt="User" src="/static/images/avatar/1.jpg" />
          </IconButton>
          <Typography variant="subtitle1" sx={{ ml: 1 }}>
            User Name
          </Typography>
        </Box>
      </Toolbar>
    </AppBar>
  );
}

export default Header;
